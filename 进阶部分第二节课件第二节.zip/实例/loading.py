# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'C:\安全牛\第二节课\第二课时\直播\动态加载\loadding.ui'
#
# Created by: PyQt5 UI code generator 5.13.0
#
# WARNING! All changes made in this file will be lost!

from PyQt5 import QtCore, QtGui, QtWidgets, Qt
from PyQt5.QtWidgets import QWidget
from PyQt5.QtGui import QMovie
import loading_rc_rc
import time

class Ui_Form(object):
    def setupUi(self, Form):
        Form.setObjectName("Form")
        Form.resize(523, 393)
        self.label = QtWidgets.QLabel(Form)
        self.label.setGeometry(QtCore.QRect(130, 100, 261, 201))
        # self.label.setStyleSheet("image: url(:/bg/china.gif);")
        self.label.setObjectName("label")
        self.label_2 = QtWidgets.QLabel(Form)
        self.label_2.setGeometry(QtCore.QRect(210, 350, 101, 20))
        self.label_2.setObjectName("label_2")
        self.retranslateUi(Form)
        QtCore.QMetaObject.connectSlotsByName(Form)
        # 设置GIF图片源
        self.gif = QMovie(r"test.gif")
        # 设置GIF位置以及大小---和label一致
        self.gif.setScaledSize(self.label.size())
        # 使用label加载GIF
        self.label.setMovie(self.gif)
        # 播放GIF
        self.gif.start()


    def retranslateUi(self, Form):
        _translate = QtCore.QCoreApplication.translate
        Form.setWindowTitle(_translate("Form", "Form"))
        self.label_2.setText(_translate("Form", "程序启动中..."))
        self.setAttribute(Qt.Qt.WA_TranslucentBackground)
        self.setWindowFlags(Qt.Qt.FramelessWindowHint)