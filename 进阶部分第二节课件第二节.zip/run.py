# -*- coding:UTF-8 -*-
from PyQt5.QtWidgets import QApplication,QMainWindow,QWidget
from PyQt5.QtWebEngineWidgets import *
from PyQt5.QtWebEngineCore import *
from PyQt5.QtCore import QUrl,pyqtSlot,QTimer
from PyQt5.QtWebEngineWidgets import QWebEnginePage
import login
import information
import loading
from PyQt5 import Qt
import sys
from bs4 import BeautifulSoup
import requests
from requests.packages.urllib3.exceptions import InsecureRequestWarning
# 禁用安全请求警告
requests.packages.urllib3.disable_warnings(InsecureRequestWarning)



class mainwindows(QMainWindow,loading.Ui_Form):
    def __init__(self):
        super(mainwindows,self).__init__()
        # self.windows = loading.Ui_Form()
        self.setupUi(self)

    def mousePressEvent(self, event):
        try:
            if event.button() == Qt.Qt.LeftButton:
                self.m_flag = True
                self.m_Position = event.globalPos() - self.pos()  # 获取鼠标相对窗口的位置
                event.accept()
                self.setCursor(Qt.QCursor(Qt.Qt.OpenHandCursor))  # 更改鼠标图标
            else:
                print('111')
        except Exception as e:
            print(e)
    def mouseMoveEvent(self, QMouseEvent):
        if Qt.Qt.LeftButton and self.m_flag:
            self.move(QMouseEvent.globalPos() - self.m_Position)  # 更改窗口位置
            QMouseEvent.accept()

    def mouseReleaseEvent(self, QMouseEvent):
        self.m_flag = False
        self.setCursor(Qt.QCursor(Qt.Qt.ArrowCursor))

class Newwindow(QWidget,login.Ui_Form):
    def __init__(self):
        super(Newwindow,self).__init__()
        self.setupUi(self)
    @pyqtSlot()
    def on_pushButton_clicked(self):
        self.user = self.textEdit.toPlainText()
        self.password = self.textEdit_2.toPlainText()
        print(self.user,self.password)
        session = requests.Session()
        rreq = session.get(url='http://basetest.m9kj-team.com:9999/login.php')
        soup = BeautifulSoup(rreq.text, 'html.parser')
        user_token = soup.find('input', type='hidden')['value']
        print(user_token)
        session.post(url='http://basetest.m9kj-team.com:9999/login.php', data={
            "username": self.user,
            "password": self.password,
            'Login': 'Login',
            'user_token': user_token
        })
        ssr = session.get('http://basetest.m9kj-team.com:9999/security.php')
        # print(ssr.text)
        soup_level = BeautifulSoup(ssr.text, 'html.parser')
        result = soup_level.find('form', {'method': 'POST'}).p.em.string
        print('用户名是：%s,密码是：%s,难易程度：%s' % (self.user, self.password, result))
        self.webView.setHtml(ssr.text)
class WebEngineUrlRequestInterceptor(QWebEngineUrlRequestInterceptor):
    def __init__(self, parent=None):
        super().__init__(parent)
    def interceptRequest(self, info):
        print(info.requestUrl(),info.requestMethod(),info.resourceType(),info.firstPartyUrl())

class infowindows(QWidget,information.INFO_Form):
    def __init__(self):
        super(infowindows,self).__init__()
        self.setupUi(self)
    @pyqtSlot()
    def on_pushButton_clicked(self):
        self.user = self.textEdit.toPlainText().split(',')
        self.password = self.textEdit_2.toPlainText().split(',')
        print(self.user,self.password)
        dic = dict(map(lambda x, y: [x, y], self.user, self.password))
        for user,password in dic.items():
            session = requests.Session()
            rreq = session.get(url='http://basetest.m9kj-team.com:9999/login.php')
            soup = BeautifulSoup(rreq.text, 'html.parser')
            user_token = soup.find('input', type='hidden')['value']
            print(user_token)
            session.post(url='http://basetest.m9kj-team.com:9999/login.php', data={
                "username": user,
                "password": password,
                'Login': 'Login',
                'user_token': user_token
            })
            ssr = session.get('http://basetest.m9kj-team.com:9999/security.php')
            # print(ssr.text)
            soup_level = BeautifulSoup(ssr.text, 'html.parser')
            result = soup_level.find('form', {'method': 'POST'}).p.em.string
            print('用户名是：%s,密码是：%s,难易程度：%s' % (user, password, result))
            self.textBrowser.append('用户名是：%s,密码是：%s,难易程度：%s \n' % (user, password, result))


if __name__ == '__main__':
    app = QApplication(sys.argv)
    wd = Newwindow()
    loadwd = mainwindows()
    ifwd = infowindows()
    view = QWebEngineView()
    page = QWebEnginePage()
    t = WebEngineUrlRequestInterceptor()
    page.profile().setRequestInterceptor(t)
    loadwd.show()
    QTimer.singleShot(2000, wd.show)
    QTimer.singleShot(2000, loadwd.close)
    # wd.setWindowOpacity(0.5)
    btn=wd.pushButton_3
    btn.clicked.connect(wd.close)
    btn.clicked.connect(ifwd.show)
    sys.exit(app.exec())